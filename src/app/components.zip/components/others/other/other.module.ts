import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OtherComponent } from './other.component';
// import { FusionChartsModule } from 'angular-fusioncharts';

// // Import FusionCharts library and chart modules
// import * as FusionCharts from 'fusioncharts';
// import * as Charts from 'fusioncharts/fusioncharts.charts';
// import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
// import * as Fusion from 'fusioncharts/themes/fusioncharts.theme.fusion'


// FusionChartsModule.fcRoot(FusionCharts, Charts, Fusion)

@NgModule({
  declarations: [OtherComponent],
  imports: [
    CommonModule,
    // FusionChartsModule.forRoot(FusionCharts , Charts)
    // FusionChartsModule
  ],
  exports:[OtherComponent]
})
export class OtherModule { }
