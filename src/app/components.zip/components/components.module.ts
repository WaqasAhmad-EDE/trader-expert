import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GraphModule } from './graphs/graph.module';
import { TableModule } from './tables/table.module';
import { OtherModule } from './others/other/other.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    GraphModule,
    TableModule,
    OtherModule
    
  ],
  exports: [
    GraphModule,
    TableModule,
    OtherModule
  ]
})
export class ComponentsModule { }
