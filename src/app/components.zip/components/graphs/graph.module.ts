import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MiniLineGraphComponent } from './mini-line-graph/mini-line-graph.component';
import { NgApexchartsModule } from 'ng-apexcharts';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { MiniCandlestickGraphComponent } from './mini-candlestick-graph/mini-candlestick-graph.component';
import { GoogleChartsModule } from 'angular-google-charts';
import { IgxFinancialChartModule, IgxLegendModule } from "igniteui-angular-charts";



@NgModule({
  declarations: [MiniLineGraphComponent, MiniCandlestickGraphComponent],
  imports: [
    CommonModule,
    NgApexchartsModule,
    CommonModule, FormsModule, IonicModule,
    GoogleChartsModule,
    IgxFinancialChartModule,
    IgxLegendModule
  ],
  exports:[
    MiniLineGraphComponent,
    MiniCandlestickGraphComponent
  ]
})
export class GraphModule { }
