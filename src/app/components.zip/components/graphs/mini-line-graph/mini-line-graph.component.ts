import { Component, OnInit, ViewChild, Input } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { DataApiService } from 'src/app/services/data-api/data-api.service';

import {
  ChartComponent,
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexYAxis,
  ApexDataLabels,
  ApexTitleSubtitle,
  ApexStroke,
  ApexGrid
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  yaxis: ApexYAxis;
  dataLabels: ApexDataLabels;
  grid: ApexGrid;
  stroke: ApexStroke;
  title: ApexTitleSubtitle;
};

@Component({
  selector: 'app-mini-line-graph',
  templateUrl: './mini-line-graph.component.html',
  styleUrls: ['./mini-line-graph.component.scss'],
})

export class MiniLineGraphComponent implements OnInit {
  // @Input("data") data: any
  // @Input("name") name: any
  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;

  name: null
  AllCurrPairs: any = []
  DisplayCurrPair = []
  URL = 'https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=EUR&to_symbol=USD&apikey='
  Key = "demo"
  charts = []
  currTern = 0

  paused = false

  tableData: any
  DisplayTableData = []

  constructor(
    private apiService: DataApiService,
    private httpClient: HttpClient
  ) {
  }


  ionViewWillEnter() {
    this.paused = false
  }
  focused() {
    // if(this.check){
    //   if(this.paused){
    //     this.paused = false
    //     this.check = false
    //   }
    // }
    // if (!this.paused) {
    //   // this.paused = false
    //   return
    // }
    // this.paused = false
  }
  ngOnInit() {


    this.apiService.AllCurrPairs.subscribe(res => {
      this.AllCurrPairs = res.valueOf()
      this.DisplayCurrPair = this.AllCurrPairs.slice(50, 100)
    })
    this.apiService.exchangeRateKey.subscribe(res => {
      this.Key = res
      this.getTable(res)
    })

    setInterval(() => {
      if (!this.paused) {
        this.currTern = Math.trunc(Math.random() * this.AllCurrPairs.length)
        this.URL = "https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=" + this.AllCurrPairs[this.currTern].split('-')[0] + "&to_symbol=" + this.AllCurrPairs[this.currTern].split('-')[1] + "&apikey=" + this.Key
        this.getData(this.AllCurrPairs[this.currTern])
      }
    }, 5000)

  }

  hid = true

  getTable(key) {

    this.DisplayTableData = []
    let names = ["EUR-USD", "USD-JPY", "GBP-USD", "AUD-USD", "USD-CAD"]


    names.forEach(element => {


      this.httpClient.get(
        "https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=" + element.split("-")[0] + "&to_symbol=" + element.split("-")[1] + "&apikey=" + key
      ).subscribe(res => {

        console.log(res);


        let dataObj = Object.entries(res["Time Series FX (Daily)"])
          .slice(0, 15)
        let o = parseFloat(dataObj[0][1]["1. open"]);
        let oc = parseFloat(dataObj[0][1]["4. close"]);
        let c = parseFloat(dataObj[dataObj.length - 1][1]["4. close"]);
        let change = -1 * ((c - o) / c * 100)

        this.DisplayTableData.push({
          name: element,
          open: o.toFixed(3),
          close: oc.toFixed(3),
          change: change.toFixed(3)
        })
      })

    });
    console.log(this.DisplayTableData);



  }



  getData(name) {
    this.httpClient.get(this.URL)
      .subscribe(res => {
        let data = []



        let dataObj = Object.entries(res["Time Series FX (Daily)"])
          .slice(0, 15)

        dataObj.forEach((p) => {
          data.unshift({
            x: p[0],
            y: [
              parseFloat((p[1])["1. open"]),
              parseFloat((p[1])["2. high"]),
              parseFloat((p[1])["3. low"]),
              parseFloat((p[1])["4. close"]),
            ],
          })
        })
        // this.charts.pop()
        // this.charts.push({ chartdata: data, name: name })
        this.name = name
        this.createChart(data)
      })
  }


  createChart(data) {
    this.hid = false
    this.chartOptions = {
      series: [{
        data: data
      }],
      chart: {
        type: "candlestick",
        zoom: {
          enabled: false
        },
        toolbar: {
          show: false
        },
        events: {
          dataPointSelection: (event, chartContext, config) => {
            console.log("hi");

            this.paused = !this.paused
          },
          
        },

      },
      stroke: {
        curve: "smooth",
        width: 1
      },
      grid: {
        xaxis: {
          lines: {
            show: false
          }
        },
        yaxis: {
          lines: {
            show: false
          }
        }
      },
      xaxis: {
        labels: {
          show: false
        },

        axisBorder: {
          show: false
        },
        axisTicks: {
          show: false
        },
      },
      yaxis: {
        labels: {
          show: false
        },

      }
    };

  }

}
