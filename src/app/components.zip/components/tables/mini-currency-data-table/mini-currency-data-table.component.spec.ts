import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MiniCurrencyDataTableComponent } from './mini-currency-data-table.component';

describe('MiniCurrencyDataTableComponent', () => {
  let component: MiniCurrencyDataTableComponent;
  let fixture: ComponentFixture<MiniCurrencyDataTableComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MiniCurrencyDataTableComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MiniCurrencyDataTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
