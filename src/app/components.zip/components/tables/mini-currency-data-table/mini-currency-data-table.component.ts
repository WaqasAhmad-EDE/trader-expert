import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mini-currency-data-table',
  templateUrl: './mini-currency-data-table.component.html',
  styleUrls: ['./mini-currency-data-table.component.scss'],
})
export class MiniCurrencyDataTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
