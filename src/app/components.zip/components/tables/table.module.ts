import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MiniCurrencyDataTableComponent } from './mini-currency-data-table/mini-currency-data-table.component';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';



@NgModule({
  declarations: [MiniCurrencyDataTableComponent],
  imports: [
    CommonModule,
    CommonModule, FormsModule, IonicModule
  ],
  exports: [
    MiniCurrencyDataTableComponent
  ]
})
export class TableModule { }
